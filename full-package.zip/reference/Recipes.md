# Feature recipes

These are independent recipes. Select, adapt or omit them; none is a required world architecture.

**Narrative instructions plus AI-updated trackers.** A relationship, journal, outfit, reputation or story-preference tracker can update from the ongoing story without an explicit mechanical action parser. Explain what belongs in it, when to add/change/remove entries, and what should remain stable. Match structured entries by stable identity or names/aliases as appropriate, not a list position that may change. Provide a useful format example; sample data must not silently become real world facts.

**A situation followed by a consequence.** Situation-trigger effects follow story generation; guidance does not retroactively rewrite the scene that caused it. If a behavior must shape that scene, provide the rule beforehand in active instructions. Use triggerOnEvent for a narrative situation the AI recognizes, optionally AND a tracker/turn/prerequisite condition to narrow it. Situation classification is probabilistic; use explicit predicates only for requirements that genuinely need exact enforcement.

**A threshold or dependency chain.** A relationship threshold can unlock a new characterization block; a turn condition can introduce weather or a letter; a prior event can enable another event. Intentional one-shot/repeat flags and firedThisTurn scope matter. Check order where the later trigger reads an earlier result. Avoid requiring and blocking the same trigger.

**Choice/input plus later effects.** Present a selection or text form targeting a real tracker, then respond with a later ordered trigger. Correctly bound single-answer forms update immediately. Inspect binding after import; use current tracker data rather than initialValue from the live-world editor export.

**AI update buffer plus scripted merge.** The library's update trackers let the AI propose changed structured entries, while a script merges them into a persistent list. Root the buffer in a record (`entries: []`); list-rooted AI buffers lose updates, even with "append-only" wording. A record root can still jam: the AI may write rows as one nested list (`entries: [[…]]`), and a merge gated on `.entries.any(name.exists())` then never fires again. Gate on a non-empty inbox, drop or unwrap non-record items, and flag an inbox still full after the merge. Match records by identity and ask for complete entries: the buffer is cleared after each merge, so field patches have nothing to apply to.

**Conditional instruction content.** Use a native block-modification effect to add/replace/clear instructions. The source may be fixed text in the effect or text prepared in a tracker by an earlier script trigger. A script changes tracker values; the native effect changes the instruction block. Keep the block ID stable when disabling content so later re-enabling still targets a real block.

**Player-optional block, with no repeated writes.** The pattern in ../examples/optional-block.json:

1. A player-only text preference has initialValueBasedOnPC player, initialValue On or Off, initialValueChoices [On, Off], autoUpdate false. The player picks it at startup; later changes need the Storyteller-mode tracker editor.
2. A hidden non-AI-updated text tracker (hidden_boring in the example) records which choice has actually been applied. It is a cache, not another player preference.
3. A repeatable enabling trigger requires preference On AND cache not Enabled. It writes the enabled block content, then records Enabled.
4. A repeatable disabling trigger requires preference Off AND cache not Disabled. It writes empty content, or a deliberately chosen simpler fallback, then records Disabled.
5. Enable opening and later execution where needed. Initialize the cache empty so the selected startup choice gets applied. Once synchronized, neither trigger fires until the preference changes.

Clear with `content: ""`; do not delete the block. If the bundle also changes authorStyle or specialist rules, restore all of it to a coherent fallback (for Storymaster: ordinary narration, no Storymaster specialists or trackers).

Preference trackers can be hidden from the storyteller; triggers still read them. Tell the player the effect and turn cost, and never let an AI-updated tracker change the choice back.

**Rules, not code.** IW runs only native triggers and PawScript. Pseudo-code in instructions or a Give information effect (`character.flags['x'] = true`, `narrative.queue(...)`, `driftFromTag(outfit)`, hourly ticks, `{{bar:x}}` placeholders) is plain text the AI may or may not imitate: it sets nothing, and its variables don't exist. Every number a rule reads needs a tracker, every timed rule needs a trigger or a turn-counted condition, and a status line the AI writes needs a tracker or a plain-language instruction. State each rule once, in words.

**More exact mechanics when requested.** Script-owned numbers, independent prerequisite checks, a request-classification tracker or a controlled transaction may be useful for a precise system. If used, define who updates each value and avoid competing AI/script ownership of the same data. Freshness stamps are for consuming an AI-generated per-turn request, not for ordinary narrative trackers.

**Level-up menu.** An AI-updated XP number and a player-chosen threshold tracker. A repeatable trigger fires when XP is at least `$threshold` (a `$variable` requiredValue is read live [RUNTIME]), opens a single-select Present Choice whose `choices` is `<<$player.skills.where(value() < 5).keys().plain_list().title_case()>>`, so maxed skills drop out, into a hidden tracker, and resets XP. One repeatable trigger per skill matches that tracker, raises the skill with Change player skill (cap 5) and sets the tracker back to none. Match each condition to the exact text the menu shows for that skill (check it in the sandbox: multi-word skills come from slugs), and give every skill its own value: a copied condition makes one pick raise two skills and another raise none. Subtracting the threshold instead of resetting to 0 keeps overflow XP [PATTERN, one community world].

**Goal reached, game continues.** When the world's objective is met (a situation trigger, optionally narrowed by a tracker), one trigger shows a message, ends the game with continuation allowed (`effectEndsGame` true, see [Runtime](Runtime.md)), and replaces the route's instruction block with post-goal rules: what the player now controls, the new pressures, an open sandbox [PATTERN, one community world].

**Per-character thresholds.** When several NPCs each move along the same scale (corruption, trust, suspicion), give each NPC its own number tracker (or a script-owned record per NPC), never one shared number the rules read "per girl". One one-shot trigger per NPC and threshold (`triggerOnTrackedItem` at least 25, 50, 75) tells the AI what changes for that NPC from now on, or swaps in that NPC's next characterization block. One-shot is the right default here; endings that need all of them ("every NPC at 90+") become one PawScript condition [PATTERN; the parts are standard, the combination is not run].

**Player-introduced items stay as given.** In worlds where the player plants or gives an object that acts on NPCs (clothing, a charm, a potion), tell the storyteller the item keeps exactly the description the player gave: an NPC may refuse or store it, but never reskins it, shrinks its effect or turns it into a protection against the mechanic. Narrators otherwise shield NPCs by quietly rewriting the item [PATTERN, one community world].

**Closed magic.** When the premise has one supernatural source, say so and close the rest: the effect stays with whoever uses that source, does not spread to others, the house and objects have no will, there is no telepathy, and a character who believes in other magic is wrong. Without it, narrators tend to escalate the weirdness on their own [PATTERN, one community world].

**Set-piece entrance.** For a boss or other big moment, a situation trigger on the threshold ("When the player opens the door to the boss room in the Verdant Temple") sends one Tell the AI what should happen next turn with the arena, the voice and the creature, ending in an instruction to close the page with a bold title card. That text lasts one turn, so keep a short standing note (personality, weak point) in the instructions or a keyword block for the rest of the fight. A second situation can hold the reveal back until the player acts. Describe what the player sees and hears, and leave their reaction to them [PATTERN, one community world].

**Escalation keyed to quest progress.** Tie the world's worsening to a Number count of the quest items (stones, seals) rather than to time, so exploring is never punished: non-repeatable triggers at `at_least` 2, 3, 4 and so on. Keep the count in a Number tracker: on a Text tracker only contains or does-not-contain applies, so a value written "1/5" contains "5" and fires the last step on the first item, and names ("Verdant Stone") fire nothing. Give information to AI is background for the turn it fires, not standing text, so let each step also replace a short World State block that lasts until the next step. Per-character change can use the same shape: an AI-updated Number and milestone triggers that each replace a stage block (the AI cannot count turns for "add 1% every five turns") [PATTERN, one community world; the Number and block mechanisms RUNTIME].

**Time and location: a soft default.** Offer the sample's Time and Location (whereWhen) block unless the premise makes a clock/location header unhelpful. It helps chronology and orients the player. Adapt the geography, calendar and precision to the setting; omit irrelevant levels rather than inventing a country or continent. Put exactly one header at the beginning of outcomeDescription, not a second competing heading.

**NPCs, keyword blocks and always-on blocks** are chosen by intended activation; see [Characters.md](Characters.md#keyword-blocks).

## Dynamic content

Text installed by a block-modification effect is a snapshot of its `<<...>>` values; the ways to keep a value live are in [Runtime.md](Runtime.md#template-interpolation-runtime). A block reinstalled every turn freezes values when its trigger runs, so values set by triggers below it arrive a turn late: order producers above the installer, or use `<=...=>`.

**Player-selected layered openings.** Combine independent choices into meaningful variations using ordered text replacements, then install the result as background. This avoids authoring every full combination; keep fragments compatible and add combination-specific handling where needed. See [layered opening](../examples/recipe-layered-opening.json).

**On-demand generation with retained results.** Install a substantial generation brief only when needed, store a compact result, and clear the brief after a matching completed request. Do not clear merely because a turn elapsed. Prefer infrequent event-driven requests; retained tracker context and AI updates can outweigh the omitted instructions. See [on-demand generation](../examples/recipe-on-demand-generation.json).


**Scene-gated sections.** For large reference text (creature guides, image rules), keep one always-on block and wrap each section in a live `<<if(flag, '…', "")>>`. A straight `'` inside the section, even in "subject's", ends the string and the section never renders: write ’ or reword. A script high in the trigger list sets the flags from scene state, for example AI-written tags matched against synonym lists in a hidden tracker, with a cap on how many count. Only rendered text bills, at the full instructions rate; a false section costs nothing [RUNTIME, Dolphin]. Gates read the previous turn's end, so check turn 1 against the start-of-game state: default-on gates or a "load everything" seed make the opening expensive. `try($scene.flag, true)` fails open (no scene data loads everything); `try(…, false)` fails closed. Choose per section.

**Lookahead.** Also gate on an AI-written list of who or what is expected next turn. For an unannounced arrival, tell the narrator to end the turn on the arrival and describe them next turn.

**Self-configuring setup.** A hidden tracker with empty fields. A start-of-game trigger copies any author-filled fields to a hidden seed, then sets the tracker ai_only with updates on; its update instructions say fill only empty fields, once. The AI fills it on turn 1 [RUNTIME, Dolphin]. A mid-game Keep trigger (turns 1–3) restores seeded fields; a one-shot Lock (all filled, or turn 3) hides it with updates off. Blocks read it by template, so it bills once, as instructions.

**Offstage archive.** A script moves records of characters unseen for N turns (script-set lastSeenTurn) to a hidden tracker and restores them when the name returns in an update or the lookahead list. List archived names in the update instructions by template so spellings are reused.

**Place archive.** For places the player returns to, keep the current place in one ai_only record (look, people, laws, open plot) and the rest in a hidden archive keyed by a place key the AI writes. Each turn a script compares the key with last turn's: on a change it files the record under the old key, then restores the new key's record or starts a blank one. A stage flag set from which fields are still empty picks a one-turn instruction ("now write the look", "now write the people and laws", "returning after N days"), so building a place spreads over turns with no long always-on rule. A move the AI never writes into the key is invisible to the script, so keep that rule short and loud [PATTERN, one community world].

**Per-place picture style.** The image-style wrappers (imageStyleCharacterPre/Post, imageStyleNonCharacterPre/Post) can be templates reading a tracker, so a script can change the look. On arrival the AI writes a style family and short look slots (medium, artists, palette, lighting); a script compiles them into the wrapper text and archives them with the place [PATTERN, community worlds; styles changed per place in play].

**Pre-seeded archive.** For a written cast, start the archive with each person's full record (per player character if circles differ); the restore step brings each in on first appearance. Hidden, so free until then; the same looks on cards bill as LTM every turn under v4. Add "never create an entry for anyone listed" [PATTERN, one community world].

**Large library, drawn by template.** Keep hundreds or thousands of items as records in hidden YAML trackers: hidden values are not sent, so storage is free. An always-on block draws with `$lib.random(n).format_each("…").join("\n")`, and only the drawn lines bill. A template draw re-rolls on every render, so store it. Prefer a script: when a restock signal changes (a day counter, a button flag), a trigger writes the drawn names to a hidden tracker and the block lists `$lib.where(name in $drawn)`. If the AI copies the names instead, a retyped name drops out silently, an empty copy redraws next turn, and the new draw shows a turn after the signal [PATTERN, one community world; failure modes read from the file, not measured].

**Rules gated on what is present.** Render each category's rules only while one of its items is in play, `<<if($dolls.any(name in $present), "DOLL RULES…", "")>>`, and a combo line when two categories are both present. Rules for an effect that outlasts its item must also be gated on that effect's state, a progress tracker or the name in an effects log, or they leave with the item while the effect runs.

**Setup dropdowns with a Custom checklist.** Player-chosen dropdown trackers (initialValueChoices, initialValueBasedOnPC player) are read by templates and Start triggers; compare each with its exact choice strings. A Custom choice opens a multi-select Present Choice into a hidden tracker; start each line with a unique prefix ("Angels:") and test `$picked contains "Angels:"`, checking no prefix appears inside another line. The AI needs only the rendered consequences, so the dropdown trackers can be player_only.

**Player-chosen cost options.** Offer the expensive extras as player_only dropdowns at character select. Start-of-game triggers read each one: install the block or swap descriptionRequest when chosen, hide and switch off the tracker that serves it when not, then hide the dropdown itself. Hidden trackers and empty blocks are not billed, so an unchosen extra costs nothing; tell the player what each choice adds per turn. The same triggers can hide trackers that only one starting route uses. Use the player-optional block pattern above instead when the choice must be changeable mid-game [PATTERN, one community world; hidden-tracker billing RUNTIME].

## Turn-state patterns

Optional patterns; trigger order is execution order.

**Script calendar.** The AI writes only the story date (`2055-10-12`). A script after the updates refuses a date earlier than the last, appends `$d.format_date("weekday")`, counts days from the first date, and writes a strip of nearby dates (`Tue 12 Oct (TODAY) · Wed 13 Oct · …`) that a block shows; the narrator takes weekdays and day counts only from it, since AI-kept counts drift [PATTERN, one community world: 40 turns, no wrong weekday].

**Script-awarded achievements and tips.** A script computes each achievement from state, adds new ones to a player_only list and states them in a one-turn beat for the AI to voice; say it awards no others, or it invents some. One-shot tips work the same way: (condition, message) pairs, at most one a turn, each once, spoken by a character [PATTERN, one community world].

**Previous-value snapshot.** The last trigger (always true, repeat) copies watched values to script-only trackers: `$prev_lp = $lifepoints`. Triggers above it read this turn's change, such as `$lifepoints < $prev_lp` for a spend. AND a delta with an event condition when the story and the number must agree. Clamps (a maximum loss per turn) also go above the snapshot.

**One-turn AI write window.** To let the AI rewrite a locked tracker once, a trigger switches its automatic updating on (optionally with new update instructions), stamps `$window = $game.turn_number` and tells the AI what to write. A relock trigger ordered above it, on `$window > 0 and $game.turn_number > $window`, switches updating off and zeroes the stamp. A mid-game switch applies from the next turn (a start-of-game one is live on turn 1), so the AI writes exactly once, on the turn it receives the instruction. Keep the switch out of triggers with Request Input.

**Periodic AI updates.** Unlock a large, slow-changing tracker on `$game.turn_number % N = k` and relock on `% N = k + 1`; it is rewritten one turn in N.

**Cooldowns.** Stamp the turn in the effect and gate on `$last_x <= 0 or $game.turn_number > $last_x + 3`. A very large stamp disables the trigger for good.

**Per-turn verdict tag.** An AI-updated text tracker asks for tags judging only this turn, or None. Text-contains conditions react to each tag, and a last trigger resets it to None (copy it first to keep a record). Tags stay turn-specific; the classification is still the AI's judgement.

**Situation catalog.** For more situations than the editor's ten Scenarios, or ones a script adds mid-game (dynamic Scenarios no longer fire), keep an AI-visible, read-only YAML catalog (`id: {when: …, once: true}`) beside a per-turn tag tracker for the ids whose `when` happened. One trigger per id reacts to its tag; the last removes used one-shots from the catalog and clears the tags. Triggers must exist in advance; a script-added id wakes its dormant trigger. Bare id lists (`[]`), record roots and text tags each landed every id on 10 of 10 turns [RUNTIME, Dolphin, one run]. Use lowercase ids that don't contain one another. Mis-tags burn one-shots, so script what must be exact. The catalog's `when` text bills every turn. Adapted from a [community wiki design](https://infiniteworlds.mywikis.wiki/wiki/Morwen%27s_Situation_State_Machine).

**Wait for a well-formed write.** Gate a follow-up on the shape of an AI-written value (contains `(`, no longer contains the placeholder), not mere change, so a malformed write just waits.

**Per-model text.** `$game.ai_model` returns the display name (`Dolphin`, `Smilodon`) and text `=` is case-sensitive. Templates in a tracker's own update instructions are evaluated live, so `<<if($game.ai_model = "Dolphin", "…", "…")>>` there selects per model. Blocks can use selectedAIProfiles instead.

**Start-up codes.** A player-only text tracker at character select holds typed codes; one one-shot Text-contains trigger (case-insensitive) per code applies each. List the codes in charSelectText.

**World-stats markers.** IW's creator stats (stats page and CSV) list every trigger by ID with Games and Fired counts, so one-shot triggers can report which settings players pick and how far games get. Add a hidden Number tracker (`stats_markers`, 0) and non-repeatable triggers whose only effect is the script `$stats_markers = $stats_markers + 1`, named to sort together ("Stats: Pace = Fast"). Mark each option of a setting the player picks, at start of game and mid-game (`$pace = "Fast"`, exact and case-sensitive; `$themes.contains("Cats")` for a multi-select, with no option inside another); milestones with `>=` so a jump still counts (`$day >= 3`); turns (`$game.turn_number >= 25`); and the model (`$game.ai_model = "Dolphin"`, plus an Other marker that is `!=` every listed name). Always add "Stats: Started" on a condition that is always true: the stats' Games total also counts older versions and saved copies, so Started is the denominator. A trigger rebuilt with a new ID starts a new row, so keep marker IDs fixed across versions. Hidden values are not sent, so markers cost nothing. A zero is usually unreached or unpicked; check "How far they get" first [PATTERN, one community world; per-ID counting RUNTIME].

**Ordinal words.** `choose($e.intensity.lower(), "slight", 1, "mild", 2, "moderate", 3, 0) < 3` compares a word scale, for example to raise an entry to a minimum without lowering it.

## Request and commit example

In [recipe-request-commit.json](../examples/recipe-request-commit.json), the AI records the current requested event and turn stamp. The first trigger resets the receipt, not the unconsumed request. A later trigger checks freshness, then checks funds/ownership and commits a purchase or rejection. A following effect displays the receipt and clears the request; the receipt remains for next-turn continuity. Narration describes an attempt until the committed result is available. A freshness stamp prevents stale reuse, not incorrect classification. The updater records the scene, not just the request: it logged narrator-invented actions as the player's until told to judge that field only from the player's own action text this turn (fixed on Dolphin). This pattern is optional: native choices, thresholds and timed effects do not need an AI request layer.

The [example index](../examples/index.json) records each complete world's purpose and verification scope. [Payloads.md](../examples/Payloads.md) supplies smaller native shapes. Remap IDs when combining worlds and validate the result.

## Guarded state patterns

Optional complete worlds built from known primitives; do not impose them on a world's design.

| Example | Intent and boundary |
| --- | --- |
| [Completion and award](../examples/recipe-completion-award.json) | Set Award state's ready field to 1 through an authored action. Commit the score and completed flag together; trigger firing alone is not successful completion. |
| [Candidate acceptance](../examples/recipe-candidate-acceptance.json) | Keep candidate and accepted records separate. Set submitted to 1 to request acceptance. Checks identity, required field existence and quantity bounds before locking. A small semantic gate, not a YAML type validator. |
| [Archive and restore](../examples/recipe-archive-reactivate.json) | Set Active record's request to archive or restore. Copy selected fields explicitly and consume the request. Whether an archived record reaches the AI depends on the tracker's visibility. |
| [Cached random](../examples/recipe-cached-random.json) | One trigger samples once and both blocks read the stored roll. Before that trigger runs the initial value is 0; reset ready to 0 only when a new draw is intended. The roll is available to narration from the next generation. |
| [Consumed milestone](../examples/recipe-consumed-timer.json) | Increment turn time before checking ticks >= 3; consume the crossing once. This counts ordinary eligible trigger cycles, not elapsed story time. |
| [Choice domain](../examples/recipe-choice-domain.json) | Accept only Courier or Archivist at consumption. Blank offers the form again; unexpected manual/script values do not commit. Multiple selections need their own delimiter/representation validation. |
| [Compiled plot](../examples/recipe-compiled-plot.json) | Literal Scenarios with ordered prerequisites and guarded awards. See the plot compiler in [tools/Usage.md](../tools/Usage.md#plot-compiler). |

The validator's review advisories are prompts to inspect intent; an existing guard can trip one (see [tools/Usage.md](../tools/Usage.md)). Choice menus and Enforce format do not validate manual or script writes.

---

END OF DOCUMENT: reference/Recipes.md
