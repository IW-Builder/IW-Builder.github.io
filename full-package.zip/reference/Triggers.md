# Triggers and effects

A trigger combines eligibility rules with effects. Its conditions are checked in a processing pass; if they pass and its repeat/prerequisite rules allow it, its effects run. Ordinary triggers are processed in triggerEvents array order. Repeat lets a trigger fire again whenever it is eligible; the condition does not have to become false in between. "HP below 5" with repeat enabled fires every turn while HP stays low, not once when it crosses below 5.

## Composition and sequencing

Each trigger has id, name, triggerConditions, triggerEffects, and explicit timing/repeat flags. Conditions are a list of nodes combined with AND; nested logic groups (and, or, none_of) are separate nodes, not leaves with type "or". Node shapes, payloads and comparator vocabulary are in [Schema.md](Schema.md) and [Payloads.md](../examples/Payloads.md). Scripts change trackers; native effects change instructions, objectives and other system properties.

Use a combined PawScript condition and sequential script when they make calculation or transaction clearer. Simple native conditions and effects remain appropriate. Keep separate triggers for phase boundaries or cross-effect dependencies. Give Scripts meaningful names describing effect; avoid generic "Update State." The owning trigger's name is useful when it describes effect. Clear script names make error reports easier.

A one-time reward can require quest_complete = 1 AND reward_claimed = 0. Its effects grant the reward and set reward_claimed = 1. An OR group could instead accept either of two qualifying quests. none_of passes when none of its child conditions pass. A state guard prevents repeated grants even if the trigger is repeatable; a one-shot trigger additionally records that it has already fired.

### Timing guidance:

The intent-to-flags table (one-time setup, setup plus every turn, once when eligible, repeat when eligible, saved trigger) is in section 6 of the Authoring Prompt. Start enables pre-opening evaluation; additional conditions still apply except for the incompatible condition types noted below. Mid Game extends a Start-enabled trigger to ordinary turns. With Start disabled, ordinary conditional triggers do not require Mid Game.

Start + Mid Game + Repeat can execute before the opening and again during turn 1, so guard counters and other effects that should run only once per turn.

With Start false, Mid Game has no effect; a stored true value requires no warning or repair. A trigger with no conditions and Start false does not fire automatically, but can remain available for explicit dispatch.

- Prerequisites/blockers with firedThisTurn true are this-turn checks that see a producer only when it is earlier in triggerEvents, and reset each turn. False uses game history, which sees a later-ordered producer from the next turn. It also sees an earlier-ordered producer on the same turn, so false means "has fired, this turn or before" and cannot defer a consumer to the next turn. To defer, order the consumer above its producer, or gate it on a stored turn stamp such as `$game.turn_number > $x.stamp_turn`. The editor disallows requiring and blocking the same trigger; do not generate that conflict.
- Always serialize canTriggerMoreThanOnce and the timing flags explicitly rather than relying on defaults. Use repeatable commit triggers with idempotent state guards where appropriate, and true one-shot events when required.
- Restriction: Do not combine Start of Game with Scenario or minimum-turn conditions. The editor warns that these conditions are ignored; minimum-turn bypass is confirmed during both startup and mid-game execution. Use a separate startup trigger and leave Start off on the conditional trigger.

### Execution order and effect semantics:

1. Later triggers see earlier committed writes, including that turn's AI tracker updates and correctly bound Present Choice/Request Input answers. This does not describe every internal generation stage. Conditions below a script, native and PawScript, see its write in the same pass; conditions above it see the old value. One Dolphin run nonetheless saw a native condition fire a turn late after a script that read an AI-updated value, so where the turn matters, make the condition true both before and after the write.
2. Native numeric Set/Add effects within one trigger overwrite rather than accumulate (add 2 then add 3 ends at 3). Reads can nevertheless see changed values, so a later native effect's expression may or may not see an earlier native write in the same trigger.
3. Run Script is different: sequential arithmetic accumulates, nested YAML changes preserve unrelated keys, and a failing script rolls back only its own writes, not earlier successful effects. The trigger still counts as fired, consumes its one-shot and satisfies prerequisites, so an explicit completion flag set inside the script is distinct from firing history. For dependent operations prefer one script; otherwise put preparation in one trigger and consumption in a following trigger.
4. Native text additions stack; removal removes all matches and literal quotes are retained. Do not apply numeric overwrite behavior to text or script statements.
5. When guidance effects conflict, the first tends to win. Generate one coherent, mutually exclusive guidance outcome rather than contradictory directives whose priority you hope to control.

Detail and evidence for each of these is in [Verified-Behavior.md](Verified-Behavior.md).

## Choosing Implementation:

| Approach | Best suited to | Main trade-off |
|---|---|---|
| Instructions and AI-updated trackers | Narrative judgment, descriptive state and flexible interactions | Outcomes depend on model interpretation; unsuitable for guaranteed arithmetic or enforcement |
| Native conditions and effects | Simple rules, editor-friendly customization and platform operations | Repeated cases can require many entries; native effect sequencing needs care |
| PawScript | Exact calculations, structured state, collection operations and repeated logic | Requires code maintenance; only supported writable values can be changed |
| Hybrid | Calculated outcomes combined with messages, block updates, opening changes or other native operations | Requires explicit ordering between calculation and application |

Native comparisons and PawScript conditions are both evaluated mechanically. Neither inherently makes narration more reliable. Use AI instructions to explain the intended behavior and deterministic conditions/scripts where exact enforcement matters.
Consolidate repeated logic when it improves clarity, but preserve meaningful execution stages and useful debugging boundaries. Consider where content is stored: moving inactive trigger payloads into AI-visible trackers can increase context cost. Performance gains from consolidation require measurement.

## Start-of-game effect restrictions

[RUNTIME] Some effects behave differently when Start of Game is enabled:

- **Give information to AI** (`effectGiveInfo`) is ignored with Start enabled, including later ordinary activations of a Start+Mid trigger. Put opening context in background or an instruction block, or use a separate ordinary-play trigger. Tell the AI what should happen next turn (`effectTellAIWhatToDo`) is a different effect and is not covered by this restriction. The validator warns for `effectGiveInfo` whenever Start is enabled.
- **Change background** replaces the opening background in Start-only mode, not with Start+Mid; ordinary-play background or first-action changes do not rewrite an opening already shown. A template in any change effect's text is rendered once, when the effect runs; write it in the world field itself to keep it live ([Runtime](Runtime.md#template-interpolation-runtime)).
- **Fire random trigger** dispatches in ordinary play, not with Start enabled.

A trigger counting as fired means its conditions passed, not that every stored effect executed.

## Changing a tracker's definition during play

**Modify tracked item details** (`effectModifyTrackedItemDetails`) changes a tracker's definition rather than its value: Name, description, visibility, automatic updating and update instructions. Set the matching override flag for each field to change (`overrideAutoUpdate: true` with the desired `autoUpdate`, `overrideVisibility: true` with one of everyone, player_only, ai_only, hidden, ai_only_boring, hidden_boring, and so on); a field without its override is not applied.

Switching automatic updating on or off works repeatedly, from the next turn: triggers run after the AI's tracker update, so a switch on turn N affects the AI from turn N+1. It does not undo a write already made in the current turn, so plan an explicit handoff point between AI and script ownership and inspect the next turn. Re-sending update instructions is unnecessary. **Never put this effect in a trigger that also has Request Input**: the change is silently lost while messages and scripts in that trigger still run. Give it its own trigger with the same condition, which works on the same turn; treat Present Choice the same way until checked. Visibility changes apply the live player-visible/hidden grouping and can reveal a hidden tracker. Payload: [Schema](Schema.md); example: [effect-effectModifyTrackedItemDetails.json](../examples/effect-effectModifyTrackedItemDetails.json); turn-state patterns that use the switch: [Recipes](Recipes.md#turn-state-patterns).


## Capability discovery and reliable gating

Read [Trigger-Catalog](Trigger-Catalog.md) for every identified condition and effect before saying a trigger cannot do something.

Eligible no-effect triggers record firing. Random dispatch bypasses target conditions but not a consumed one-shot. Native And/Or groups and PawScript expressions short-circuit in order.

### Scenarios

Say Scenarios when talking to users; the root JSON field is `conditions`, referenced by `triggerOnEvent`. Binding requires an exact registry string, including case, spaces and punctuation; preserved JSON can still be unbound, so check the selector after import. A Scenario fires only when the event actually happens in the narrated outcome; the narrator can refuse or substitute a requested action. An event the narrator invents, or a player's purpose it rewrites, also satisfies the Scenario. Unused registry entries and duplicate references are tolerated, and import fills an absent registry from the trigger references. Use literal Scenarios with explicit state gates; dynamic Scenario text (`<<$slot>>`) did not fire at all when retested on 2026-11-01, even as a single slot, and blank slot text is not dependable deactivation. The editor stops adding Scenarios at ten entries, but imported registries of twelve or more work.

---

END OF DOCUMENT: reference/Triggers.md
