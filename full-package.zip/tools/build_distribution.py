"""Build the IW distribution from this script's repository location (no arguments).

Standard library only. Updates document markers, homepage, embedded checker tools,
chat editions and SHA-256 manifest. Does not run validation or create ZIP archives.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import html
import json
import re
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent.parent
KIT_VERSION = '1.6.0'  # also stated in reference/Verified-Behavior.md (checked by tests)

# The reference documents in reading order. The build packs them, whole files
# only, into numbered parts (IW-Reference-1.txt, -2, ...) that each stay under
# PART_CAP, adding a part when the reference grows. Part 1 always starts with
# Authoring-Prompt.md. IW-Complete-Reference.txt is all of them in one file.
REFERENCE_SOURCES = [
    'Authoring-Prompt.md',
    'World-Template.json',
    'reference/Craft.md',
    'reference/Trackers.md',
    'reference/Triggers.md',
    'reference/Trigger-Catalog.md',
    'reference/Portable-Banks.md',
    'library/Integration.md',
    'reference/Schema.md',
    'reference/PawScript.md',
    'reference/Runtime.md',
    'reference/Characters.md',
    'reference/Recipes.md',
    'reference/Notable-Findings.md',
    'reference/Editor-UI.md',
    'reference/Cost.md',
    'reference/Verified-Behavior.md',
    'examples/Payloads.md',
    'examples/index.json',
    'reference/Current-AI-Profiles.json',
    'reference/Images-and-Models.md',
    'reference/Default-Evaluation.txt',
]
PART_TARGET = 80_000  # fill target per part; the rest of PART_CAP covers the header
PART_CAP = 90_000     # hard limit per part, for tools that cap attachments or fetches near 100 KB
PART_PREFIX = 'IW-Reference-'
COMPLETE_EDITION = 'IW-Complete-Reference.txt'
# Editions replaced by the numbered parts on 2026-11-15; each keeps a short pointer file.
RETIRED_EDITIONS = ['IW-Authoring-Guide.txt', 'IW-Technical-Reference.txt', 'IW-Behavior.txt', 'IW-Payloads.txt']

# Content to pick from: attached only when the task asks for it. Not size-capped.
GROUPS = {
    'IW-Mechanics-Examples.txt': [
        'examples/recipe-request-commit.json',
        'examples/recipe-completion-award.json',
        'examples/recipe-candidate-acceptance.json',
        'examples/recipe-archive-reactivate.json',
        'examples/recipe-cached-random.json',
        'examples/recipe-consumed-timer.json',
        'examples/recipe-choice-domain.json',
        'examples/recipe-compiled-plot.json',
        'examples/recipe-choice-followup.json',
        'examples/recipe-threshold-unlock.json',
        'examples/optional-block.json',
        'examples/character-starting-values.json',
        'examples/recipe-layered-opening.json',
        'examples/recipe-on-demand-generation.json',
        'examples/showcase-glass-ledger.json',
    ],
    'IW-Narrative-Examples.txt': [
        'examples/narrative-vendemmia.json',
        'examples/narrative-listening-road.json',
        'examples/narrative-address-after-midnight.json',
        'examples/narrative-seven-nights.json',
        'examples/narrative-velvet-wager.json',
    ],
    'IW-Sample-Blocks.txt': [
        'library/Sample-Blocks.json',
    ],
    'IW-Storymaster.txt': [
        'library/Storymaster-Suite.json',
    ],
}
# Purpose of each pick-from edition, used in every edition's header so a model
# with only one file knows which companion holds a given path.
EDITION_PURPOSE = {
    'IW-Mechanics-Examples.txt': 'complete mechanics example worlds: recipes, optional block, starting values, layered opening, on-demand generation and a showcase',
    'IW-Narrative-Examples.txt': 'complete narrative example worlds: ensemble romance, fantasy expedition, contained horror, fantasy relationship and high-heat erotica',
    'IW-Sample-Blocks.txt': 'optional library modules (read library/Integration.md first)',
    'IW-Storymaster.txt': 'the Storymaster narrative-direction framework (read library/Integration.md first)',
    'IW-Tools.txt': 'Python tools and their guides, for models that can run code',
}

PAGE = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description"
        content="The Infinite Worlds authoring prompt and supporting tools.">
  <title>Infinite Worlds Authoring Prompt</title>
  <style>
    body {
      max-width: 960px;
      margin: 40px auto;
      padding: 0 24px;
      color: #202820;
      background: #fafbf7;
      font: 16px/1.6 system-ui, sans-serif;
    }
    nav {
      display: flex;
      flex-wrap: wrap;
      gap: 18px;
      margin-bottom: 28px;
    }
    a { color: #235e4b; }
    pre {
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      padding: 24px;
      border: 1px solid #dce2d8;
      border-radius: 10px;
      background: white;
      font: 14px/1.7 ui-monospace, Consolas, monospace;
    }
  </style>
</head>
<body>
  <header>
    <h1>Infinite Worlds Authoring Prompt</h1>
    <p>Send this page's link to your AI together with your request, for example:
       <code>Use https://IW-Builder.github.io/ to build: [your idea]</code>.
       The supporting kit supplies its templates and references. Kit __KIT_VERSION__.</p>
    <nav aria-label="Resources">
      <a href="chat/">Plain-text prompt</a>
      <a href="full-package.zip">Download ZIP package</a>
      <a href="checker/">Validator</a>
      <a href="llms.txt">File index</a>
      <a href="https://github.com/IW-Builder/IW-Builder.github.io/tree/main">
        README and browse files
      </a>
    </nav>
  </header>
  <main>
    <pre>__PROMPT_CONTENT__</pre>
  </main>
</body>
</html>
"""

TOOL_SOURCES = [
    'tools/Usage.md',
    'tools/validate_iw_export.py', 'tools/static_checks.py',
    'tools/iw-export.schema.json', 'tools/data_bank.py',
    'tools/import_audit.py', 'tools/story_export.py',
    'tools/plot_compile.py',
]
CHECKER_SOURCES = {
    'src-validate': 'tools/validate_iw_export.py',
    'src-static': 'tools/static_checks.py',
    'src-schema': 'tools/iw-export.schema.json',
}

def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

def write(path, content):
    dest = ROOT / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    raw = content.encode('utf-8')
    if dest.exists() and dest.read_bytes() == raw:
        return
    dest.write_bytes(raw)
    print('Wrote ' + path)

def marked(content, path):
    # Replace only the terminal marker; preserve embedded END FILE boundaries.
    content = re.sub(r'\n(?:---\n\n)?' + re.escape('END OF DOCUMENT: ' + path) + r'(?=\n|$)\n?', '\n', content)
    content = re.sub(r'\n(?:---\n\n)?END OF DOCUMENT: [^\n]+\s*\Z', '', content)
    return content.rstrip() + '\n\n---\n\nEND OF DOCUMENT: ' + path + '\n'

def document_paths():
    paths = {'Authoring-Prompt.md', 'library/Integration.md',
             'examples/Payloads.md', 'tools/Usage.md'}
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'reference').glob('*.md')
                 if p.name.lower() != 'readme.md')
    return sorted(paths)

def update_checker():
    page = read('checker/index.html')
    for ident, path in CHECKER_SOURCES.items():
        source = read(path)
        if '</script' in source.lower():
            raise ValueError(path + ' contains an HTML script closing sequence; cannot embed safely.')
        pattern = r'(<script\b[^>]*\bid="' + re.escape(ident) + r'"[^>]*>)[\s\S]*?(</script\s*>)'
        page, count = re.subn(pattern, lambda m: m[1] + '\n' + source.rstrip('\n') + '\n' + m[2], page)
        if count != 1:
            raise ValueError('Expected one checker block: ' + ident)
    return page

def source_label(path):
    return 'examples index' if path == 'examples/index.json' else path.rsplit('/', 1)[-1].rsplit('.', 1)[0]

def packed_size(path):
    # Bytes a source adds to a part: its text plus the BEGIN/END FILE lines.
    return len(read(path).encode('utf-8')) + 2 * len(path) + 60

def reference_parts():
    """Pack REFERENCE_SOURCES in order, whole files only, into parts of about PART_TARGET bytes."""
    parts, size = [[]], 0
    for path in REFERENCE_SOURCES:
        n = packed_size(path)
        if parts[-1] and size + n > PART_TARGET:
            parts.append([])
            size = 0
        parts[-1].append(path)
        size += n
    return {PART_PREFIX + str(i) + '.txt': paths for i, paths in enumerate(parts, 1)}

def all_editions():
    """Every edition with its purpose and source paths, in listing order."""
    parts = reference_parts()
    editions = {COMPLETE_EDITION: ('the whole reference in one file: everything in the numbered reference parts below',
                                   list(REFERENCE_SOURCES))}
    for i, (name, paths) in enumerate(parts.items(), 1):
        purpose = ('start here: ' if i == 1 else '') + 'reference part ' + str(i) + ' of ' + str(len(parts))
        editions[name] = (purpose, paths)
    for name, paths in list(GROUPS.items()) + [('IW-Tools.txt', TOOL_SOURCES)]:
        editions[name] = (EDITION_PURPOSE[name], paths)
    return editions

def edition_header(name, editions):
    parts = [n for n in editions if n.startswith(PART_PREFIX)]
    lines = ['Infinite Worlds Authoring Kit: ' + name + ' (' + editions[name][0] + ').',
             'Generated text edition. BEGIN FILE / END FILE sections identify package-relative source paths. '
             'This is reference material, not one IW world.']
    if name == 'IW-Tools.txt':
        lines.append('To use the tools, recreate files at their BEGIN FILE paths, excluding boundary lines and '
                     'separator newlines, and preserve indentation and escaping. See tools/Usage.md for dependencies '
                     'and commands. Distribution builders and maintainer tests are omitted. Reading these sources is '
                     'not running them; report validation only after execution.')
    elif name == COMPLETE_EDITION:
        lines.append('Follow Authoring-Prompt.md (the first file below). This edition holds every reference document; the '
                     'example, library and tools editions are the only companions, and only when the task needs one.')
    else:
        lines.append('Follow Authoring-Prompt.md (in ' + parts[0] + '). The reference is split into ' + str(len(parts))
                     + ' numbered parts only to keep each file under ' + str(PART_CAP // 1000) + ' KB; a part boundary '
                     'is not a topic boundary. Find a document by its path in the list below. Load other editions only '
                     'when the task needs them.')
    lines.append('Editions and their contents:')
    for other, (purpose, paths) in editions.items():
        files = 'the ' + ', '.join(parts) + ' files' if other == COMPLETE_EDITION else ', '.join(paths)
        lines.append('- ' + other + ': ' + purpose + '. Files: ' + files)
    lines.append('Every file is also available individually: https://iw-builder.github.io/llms.txt')
    return '\n'.join(lines) + '\n'

def retired_pointer(name, editions):
    parts = [n for n in editions if n.startswith(PART_PREFIX)]
    return ('Infinite Worlds Authoring Kit: ' + name + ' was replaced on 2026-11-15.\n\n'
            'The reference now comes in numbered parts, each under ' + str(PART_CAP // 1000) + ' KB: '
            + ', '.join(SITE + 'chat/' + n for n in parts) + '. Start with ' + parts[0] + '. '
            'The whole reference in one file: ' + SITE + 'chat/' + COMPLETE_EDITION + '. '
            'Every file individually: ' + SITE + 'llms.txt\n')

def build_chat():
    source_manifest = {}
    editions = all_editions()
    for name, (_, paths) in editions.items():
        parts = [edition_header(name, editions)]
        for path in paths:
            parts.extend(['\n===== BEGIN FILE: ' + path + ' =====\n', read(path),
                          '\n===== END FILE: ' + path + ' =====\n'])
        text = ''.join(parts).rstrip() + '\n\nEND OF DOCUMENT: chat/' + name + '\n'
        if name.startswith(PART_PREFIX) and len(text.encode('utf-8')) >= PART_CAP:
            raise ValueError(name + ' is over ' + str(PART_CAP) + ' bytes; lower PART_TARGET.')
        write('chat/' + name, text)
        source_manifest[name] = {'sourceFiles': paths,
                                'sha256': hashlib.sha256(text.encode('utf-8')).hexdigest()}
    write('chat/sources.json', json.dumps(source_manifest, indent=2) + '\n')
    # Remove parts left over from a build that needed more of them.
    for old in (ROOT/'chat').glob(PART_PREFIX + '*.txt'):
        if old.name not in editions:
            old.unlink()
            print('Removed chat/' + old.name)
    for name in RETIRED_EDITIONS:
        write('chat/' + name, retired_pointer(name, editions))
    first = next(n for n in editions if n.startswith(PART_PREFIX))
    guide = read('chat/' + first)
    links = ',\n    '.join('<a href="' + n + '">' + html.escape(n) + '</a> (' + html.escape(purpose) + ')'
                           for n, (purpose, _) in editions.items() if n != first)
    page = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>IW Builder Authoring Guide</title>
  <style>body { max-width: 960px; margin: 40px auto; padding: 0 24px; font: 16px/1.6 system-ui, sans-serif; } pre { white-space: pre-wrap; overflow-wrap: anywhere; font: inherit; }</style>
</head>
<body>
  <h1>IW Builder Authoring Guide</h1>
  <p>Start here. This page contains __FIRST__: the prompt, template and the first part of the reference. Other editions, only when needed (IW-Complete-Reference.txt is every reference document in one file, for attaching to a chat):
    __LINKS__.
    Individual files: <a href="https://iw-builder.github.io/llms.txt">llms.txt</a>.</p>
  <main><pre>__GUIDE_CONTENT__</pre></main>
</body>
</html>
"""
    write('chat/index.html', page.replace('__FIRST__', first).replace('__LINKS__', links)
          .replace('__GUIDE_CONTENT__', html.escape(guide)))


def manifest_paths():
    # Explicit publication scope excludes stories/ (released games, not kit material), Git internals, caches and archives.
    paths = {ROOT/p for p in ['Authoring-Prompt.md', 'World-Template.json',
                              'README.md', 'LICENSE', 'index.html', 'llms.txt'] if (ROOT/p).is_file()}
    suffixes = {'.md', '.txt', '.json', '.py', '.html', '.js', '.css', '.svg', '.yml', '.yaml'}
    for folder in ['reference', 'library', 'examples', 'tools', 'chat', 'checker', 'cost']:
        for p in (ROOT/folder).rglob('*'):
            rel = p.relative_to(ROOT)
            if (p.is_file() and not p.is_symlink() and p.suffix.lower() in suffixes
                and not any(x.startswith('.') or x == '__pycache__' for x in rel.parts)
                and p.name not in {'build_chat_edition.py', 'build_prompt_page.py'}):
                paths.add(p)
    return sorted(paths, key=lambda p: p.relative_to(ROOT).as_posix())

def build_manifest():
    records = []
    for p in manifest_paths():
        data = p.read_bytes()
        records.append({'path': p.relative_to(ROOT).as_posix(), 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})
    # Preserve the timestamp when the represented bytes have not changed.
    old = {}
    try:
        old = json.loads(read('manifest.json'))
    except (OSError, ValueError):
        pass
    timestamp = old.get('generatedAt') if old.get('files') == records else None
    result = {'algorithm': 'sha256',
              'generatedAt': timestamp or datetime.now(timezone.utc).isoformat(timespec='seconds'),
              'files': records}
    write('manifest.json', json.dumps(result, indent=2) + '\n')
    print('Manifest: ' + str(len(records)) + ' files')

# ---------------------------------------------------------------------------
# File index (llms.txt) and folder pages
# ---------------------------------------------------------------------------
# One description per published file. llms.txt and the folder index pages are
# generated from this table; example worlds take their purpose from
# examples/index.json. The build fails if a published file has no description.

SITE = 'https://iw-builder.github.io/'
GITHUB_TREE = 'https://github.com/IW-Builder/IW-Builder.github.io/tree/main/'

DESCRIPTIONS = {
    # Start here
    'index.html': 'Homepage: the authoring prompt (same text as Authoring-Prompt.md). Start here.',
    'Authoring-Prompt.md': 'The authoring prompt: task modes, which reference to read for each feature, construction, timing, validation and delivery rules.',
    'World-Template.json': 'Empty importable world; the starting point for new builds.',
    'README.md': 'Human guide: workflows, starter requests, import/export steps. Rendered at /guide/; models can skip it.',
    'LICENSE': 'MIT license.',
    # Combined text editions
    'chat/index.html': 'HTML page containing IW-Reference-1.txt (start here), with links to the other editions.',
    'chat/IW-Complete-Reference.txt': 'Combined text, all reference in one attachment (about 80k tokens): the prompt, template, every reference guide, Payloads and the example index. Too large for most URL fetchers; attach it.',
    'chat/IW-Mechanics-Examples.txt': 'Combined text: complete mechanics example worlds (recipes, optional block, starting values, layered opening, on-demand generation, showcase).',
    'chat/IW-Narrative-Examples.txt': 'Combined text: all five complete narrative example worlds.',
    'chat/IW-Sample-Blocks.txt': 'Combined text: library modules (Sample-Blocks.json). Integration guide is in the reference parts (library/Integration.md).',
    'chat/IW-Storymaster.txt': 'Combined text: the Storymaster framework (Storymaster-Suite.json). Integration guide is in the reference parts (library/Integration.md).',
    'chat/IW-Tools.txt': 'Combined text: the tool usage guide plus validator, schema and helper sources to recreate locally.',
    'chat/README.md': 'Human guide to the combined text files.',
    'chat/sources.json': 'Which source files make up each combined text file, with hashes.',
    # Reference
    'reference/Characters.md': 'Skills, Evaluation, player characters, NPC card fields and activation, keyword-block matching and retention.',
    'reference/Images-and-Models.md': 'Image style fields and controls, portraits and cover, video prompt instructions, model-specific instruction blocks.',
    'reference/Runtime.md': 'Turn lifecycle, template interpolation timing, specialist requests and runtime output names, endings, debug boundaries.',
    'reference/Cost.md': 'Estimating credits: per-model cost table (words, credits per 1k chars, thinking), what is billed, how play style changes cost, and rough estimates by world size.',
    'reference/Craft.md': 'Narrative design: what goes in each field, openings, character cards, romance and adult worlds, prose style, names, example worlds by genre.',
    'reference/Current-AI-Profiles.json': 'Storyteller models, current and retired: block IDs, underlying real-world model, isCurrent flag and typical credits per turn.',
    'reference/Default-Evaluation.txt': "IW's built-in Evaluation instructions, verbatim; the baseline for a custom Evaluation.",
    'reference/Editor-UI.md': 'Editor labels and their JSON fields, import/export steps with before/after checks, live copies, debug tools, visibility, permissions and troubleshooting by symptom.',
    'reference/PawScript.md': 'PawScript language guide: syntax, collections, randomness, formatting, debugging, system roots and common mistakes.',
    'reference/Portable-Banks.md': 'Data mode: portable character/data bank format, dependencies, full-content build reports and data_bank.py commands.',
    'reference/README.md': 'Human-friendly index of the reference guides.',
    'reference/Recipes.md': 'Ways to combine features: situation triggers, thresholds, choices, optional blocks, dynamic content, request/commit, guarded state and turn-state patterns.',
    'reference/Schema.md': 'Export structure: identifier conventions, field groups, trackers, starting values, condition and effect payloads, comparators and value-effect operations.',
    'reference/Trackers.md': 'Tracker fields, data types, visibility, update ownership, starting values and memory/context cost.',
    'reference/Trigger-Catalog.md': "Every identified trigger condition and effect type in one table. Check it before saying a trigger can't do something.",
    'reference/Triggers.md': 'Trigger timing flags, ordering, effect semantics, choosing native effects or PawScript, start-of-game restrictions and changing a tracker definition during play.',
    'reference/Notable-Findings.md': 'Plain-language list of the behavior most likely to surprise an author or break a world, with what to do, and the list of what is still unknown.',
    'reference/Verified-Behavior.md': 'Compatibility baseline, evidence labels and consolidated runtime findings: triggers, imports, PawScript, visibility, memory, forms, images and endings.',
    # Library
    'library/Integration.md': 'How to choose and adapt library modules: Storymaster versus lightweight direction, token costs, dependency checklists. Read before using the library JSON.',
    'library/README.md': 'Human-friendly overview of the library.',
    'library/Sample-Blocks.json': 'Library modules in world-file format: time/location, characterization, craft, pacing, trackers, image styles and more. Copy whole content values by name.',
    'library/Storymaster-Suite.json': 'The Storymaster narrative-direction framework in world-file format. Substantial; read Integration.md first.',
    'library/Storymaster-3-Beta.md': 'Official Storymaster 3 and 3 Proactive release text (beta) by SelfB and TWNT, unedited: reference for writing custom evaluation instructions. Using it in a world requires crediting the version and both creators in the description.',
    # Examples (individual worlds are described by examples/index.json)
    'examples/README.md': 'Human guide to the examples, grouped by what you want to do.',
    'examples/Payloads.md': 'Compact native payload snippets for every condition and effect, taken from the example worlds.',
    'examples/index.json': 'Machine index of every example world: purpose, evidence label and verification scope.',
    # Tools
    'tools/README.md': 'Human overview of the tools.',
    'tools/Usage.md': 'Commands, checks, warning meanings and limits for the validator, import audit, data banks, sorter, story extractor and plot compiler.',
    'tools/validate_iw_export.py': 'World validator: schema, references and lint; --diff compares with an original. The main tool to run.',
    'tools/iw-export.schema.json': 'JSON Schema (Draft 2020-12) profile of the IW export format, used by the validator.',
    'tools/static_checks.py': 'Lint and reference checks used by the validator.',
    'tools/data_bank.py': 'Create, check, pack/unpack and restore portable data banks and full-content build reports. Standard library only.',
    'tools/import_audit.py': 'Read-only comparison of a source world with its re-exported import: ID changes and dangling references.',
    'tools/story_export.py': 'Plan, build and verify reviewed extractions of IW story exports; merges only non-conflicting histories.',
    'tools/plot_compile.py': 'Builds a fresh world from a literal-Scenario prerequisite plan.',
    'tools/example-plot-plan.json': 'Sample input for plot_compile.py.',
    'tools/iw_sort.py': 'Exports PC, NPC, trigger and tracker names to a text list and reorders a world to match the edited list. Standard library only.',
    'tools/Validation-Report.json': 'Latest package check results (maintainer output).',
    'tools/build_distribution.py': 'Maintainer: rebuilds the homepage, combined text files, folder pages, llms.txt, checker and manifest.',
    'tools/check_package.py': 'Maintainer: validates every example world and local link; writes Validation-Report.json.',
    'tools/test_validator.py': 'Maintainer tests for the validator.',
    'tools/test_data_bank.py': 'Maintainer tests for data_bank.py.',
    'tools/test_distribution.py': 'Maintainer tests for the distribution build.',
    'tools/test_engineering.py': 'Maintainer tests for the plot compiler.',
    'tools/test_native_compat.py': 'Maintainer tests for native export compatibility.',
    'tools/test_story_export.py': 'Maintainer tests for story_export.py.',
    'tools/test_iw_sort.py': 'Maintainer tests for iw_sort.py.',
    # Cost exporter
    'cost/index.html': 'IW Cost Exporter install page: a bookmarklet that downloads your credit history with every turn\'s cost breakdown (IW\'s own download has totals only).',
    'cost/IW-Cost-Exporter-bookmarklet.js': 'Readable source of the cost-exporter bookmarklet.',
    'cost/README.md': 'Guide to the cost exporter: install, use, output columns.',
    # Checker
    'checker/index.html': "Browser validator: paste a world or a model's whole reply; runs validate_iw_export.py locally, joins numbered chunks and copies a report for the AI.",
}

# Folder pages are generated, so they are not listed in the index themselves.
FOLDER_PAGES = {
    'reference': 'Reference guides',
    'examples': 'Example worlds',
    'library': 'Sample library',
    'tools': 'Tools',
}

def descriptions():
    """DESCRIPTIONS plus the generated reference parts (after the complete edition) and retired pointers."""
    generated = {}
    for name, (purpose, paths) in all_editions().items():
        if name.startswith(PART_PREFIX):
            generated['chat/' + name] = ('Combined text, ' + purpose + ': '
                                         + ', '.join(source_label(p) for p in paths) + '.')
    for name in RETIRED_EDITIONS:
        generated['chat/' + name] = 'Old name, replaced 2026-11-15: points to the numbered reference parts.'
    result = {}
    for key, value in DESCRIPTIONS.items():
        result[key] = value
        if key == 'chat/' + COMPLETE_EDITION:
            result.update(generated)
    return result

def site_url(path):
    """Direct public URL for a published file."""
    if path == 'index.html':
        return SITE
    if path == 'README.md':
        return SITE + 'guide/'
    if path.endswith('/index.html'):
        return SITE + path[:-len('index.html')]
    return SITE + quote(path)

def size_label(nbytes):
    return str(max(1, round(nbytes / 1024))) + ' KB'

def index_entries():
    """Every published file except generated folder pages, grouped for the index."""
    examples = {item['file']: item for item in json.loads(read('examples/index.json'))}
    folder_pages = {name + '/index.html' for name in FOLDER_PAGES}
    descs = descriptions()
    groups = {}
    missing = []
    for p in manifest_paths():
        rel = p.relative_to(ROOT).as_posix()
        if rel in folder_pages or rel == 'llms.txt':
            continue
        if rel in descs:
            description = descs[rel]
        elif rel.startswith('examples/') and rel.endswith('.json') and p.name in examples:
            item = examples[p.name]
            description = item['purpose'].rstrip('.') + '. Evidence: ' + item['evidence'] + '.'
        else:
            missing.append(rel)
            continue
        group = rel.split('/')[0] if '/' in rel else 'root'
        groups.setdefault(group, []).append({'path': rel, 'url': site_url(rel),
                                             'bytes': p.stat().st_size, 'description': description})
    if missing:
        raise ValueError('No index description for: ' + ', '.join(missing)
                         + '. Add it to DESCRIPTIONS in build_distribution.py or examples/index.json.')
    # Curated order: the DESCRIPTIONS table order first, then remaining files by path.
    rank = {path: i for i, path in enumerate(descs)}
    for entries in groups.values():
        entries.sort(key=lambda e: (rank.get(e['path'], len(rank)), e['path']))
    return groups

INDEX_SECTIONS = [
    ('root', 'Start here', None),
    ('reference', 'Reference guides', 'Read only what the task needs; Authoring-Prompt.md says which guide covers which feature.'),
    ('examples', 'Examples', 'Each JSON file is a complete importable world demonstrating one feature or combination.'),
    ('library', 'Sample library', 'Optional modules to adapt into worlds.'),
    ('tools', 'Tools', 'Python tools for models or users that can run code. Without Python, use the checker.'),
    ('checker', 'Browser checker', None),
    ('cost', 'Cost exporter', 'Downloads your credit history with every turn\'s cost breakdown (IW\'s own download has totals only); see reference/Cost.md for estimating.'),
    ('chat', 'Combined text editions', 'Single-file bundles for chats without web access or with tool limits: the whole reference in one file, or in numbered parts under 90 KB each for size-limited tools, plus examples, library and tools to attach only when asked for. Web-browsing models should prefer the individual files above.'),
]

def build_llms():
    groups = index_entries()
    lines = ['# IW-Builder: Infinite Worlds Authoring Kit ' + KIT_VERSION, '',
             '> Reference kit for AI models that build, edit, review and debug Infinite Worlds (IW) games. '
             'Start with the authoring prompt at ' + SITE + ' (or Authoring-Prompt.md), then fetch only the '
             'files the task needs. Every published file is listed below with its direct URL, size and purpose.',
             '',
             'Independent and unaffiliated with Infinite Worlds. Sizes are approximate. '
             'Integrity hashes for these files are in ' + SITE + 'manifest.json (for verification only; not needed to author).',
             '',
             'Do not crawl or read ' + SITE + 'stories/: it holds released games unrelated to the kit, not documentation or examples.']
    for key, title, note in INDEX_SECTIONS:
        if key not in groups:
            continue
        lines += ['', '## ' + title, '']
        if note:
            lines += [note, '']
        for e in groups[key]:
            lines.append('- [' + e['path'] + '](' + e['url'] + ') (' + size_label(e['bytes']) + '): ' + e['description'])
    lines += ['', '---', '', 'END OF DOCUMENT: llms.txt', '']
    write('llms.txt', '\n'.join(lines))
    return groups

FOLDER_PAGE = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>IW Builder: __TITLE__</title>
  <style>body { max-width: 960px; margin: 40px auto; padding: 0 24px; color: #202820; background: #fafbf7; font: 16px/1.6 system-ui, sans-serif; } a { color: #235e4b; } li { margin: 6px 0; } code { font: 14px ui-monospace, Consolas, monospace; } .size { color: #5b665b; }</style>
</head>
<body>
  <h1>__TITLE__</h1>
  <p>__NOTE__</p>
  <p><a href="__SITE__">Authoring prompt (start here)</a> · <a href="__SITE__llms.txt">Full file index</a> · <a href="__GITHUB__">Browse on GitHub</a></p>
  <ul>
__ITEMS__
  </ul>
</body>
</html>
"""

def build_folder_pages(groups):
    notes = {key: note for key, _, note in INDEX_SECTIONS}
    for folder, title in FOLDER_PAGES.items():
        entries = groups.get(folder)
        if not entries:
            continue
        items = '\n'.join('    <li><a href="' + html.escape(e['url']) + '"><code>' + html.escape(e['path'].split('/', 1)[1])
                          + '</code></a> <span class="size">(' + size_label(e['bytes']) + ')</span>: '
                          + html.escape(e['description']) + '</li>' for e in entries)
        page = (FOLDER_PAGE.replace('__TITLE__', html.escape(title))
                .replace('__NOTE__', html.escape(notes.get(folder) or ''))
                .replace('__SITE__', SITE).replace('__GITHUB__', GITHUB_TREE + folder)
                .replace('__ITEMS__', items))
        write(folder + '/index.html', page)


def build():
    # Preflight every required input and checker embedding before changing outputs.
    required = set(document_paths() + TOOL_SOURCES + list(CHECKER_SOURCES.values()))
    required.update(REFERENCE_SOURCES)
    for paths in GROUPS.values():
        required.update(paths)
    for path in sorted(required):
        read(path)
    checker = update_checker()
    for path in document_paths():
        write(path, marked(read(path), path))
    write('index.html', PAGE.replace('__KIT_VERSION__', KIT_VERSION).replace('__PROMPT_CONTENT__', html.escape(read('Authoring-Prompt.md'))))
    write('checker/index.html', checker)
    build_chat()
    build_folder_pages(build_llms())
    build_manifest()
    print('Build complete. Validation and ZIP packaging are separate steps.')

if __name__ == '__main__':
    try:
        build()
    except (OSError, ValueError) as exc:
        raise SystemExit('Build failed: ' + str(exc))
