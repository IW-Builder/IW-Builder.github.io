# Bring the kit into your chat

These text files let you use IW Builder with an AI that accepts attachments, even if it cannot browse the website or open a ZIP.

For web retrieval, an AI can open the [authoring guide page](https://iw-builder.github.io/chat/) directly, or start from the [homepage](https://iw-builder.github.io/) and fetch individual files listed in [llms.txt](https://iw-builder.github.io/llms.txt).

For attachments, start by uploading [IW-Authoring-Guide.txt](IW-Authoring-Guide.txt) and telling the AI what you want to make. You can describe an idea, attach a world you want changed, or ask how something works. Let it ask for the other files when it needs them.

| File | What's inside |
| --- | --- |
| [Authoring Guide](IW-Authoring-Guide.txt) | The main prompt, starting template and core guides to creating worlds. Start here. |
| [Technical Reference](IW-Technical-Reference.txt) | Exact world-file structure, PawScript, platform capabilities, feature recipes and import checks. |
| [IW Behavior](IW-Behavior.txt) | Editor and UI workflows, tested platform behavior and known limits. Useful for debugging. |
| [Examples](IW-Examples.txt) | Worked examples including a platonic fantasy expedition, contained horror and ensemble romance, alongside feature recipes. |
| [Sample Library](IW-Sample-Library.txt) | Ready-made building blocks for storytelling, continuity and other optional features. |
| [Tools](IW-Tools.txt) | Code the AI can use to check worlds and handle reusable content, if it can run Python. |

You do not need to upload everything at once. If your AI cannot run the checks, you can use the [web checker](https://iw-builder.github.io/checker/) yourself and paste the results back into the conversation.

`sources.json` records which files went into each package; you can ignore it during normal use.

[Back to the main guide](https://iw-builder.github.io/guide/)
